# EvoFox Bridge (controller mapper + tester)

Maps an EvoFox Elite X2 Pro (or any Android gamepad) to touch controls on the Moto Edge 60 Fusion, plus a controller tester and vibration test.

## Build an APK
1. Open this folder in Android Studio and let Gradle sync (SDK Platform 35).
2. Build > Build APK(s). Output: `app/build/outputs/apk/debug/app-debug.apk`.
3. Install it on the phone.

## Use
1. Connect the controller in Android mode. Open the app: it should say CONTROLLER DETECTED.
2. Tap "Turn on the mapper" and enable **EvoFox Bridge Mapper** in Accessibility.
3. Tap "Set up buttons and screen positions". For each action press the controller button, then tap where that control is on the game screen. Load a screenshot of the game HUD as the background to tap exact spots. M1/M2 and back paddles go in the "Extra" slots.
4. Switch Mapping ON, open the game. The Mode/Guide button pauses/resumes mapping.
5. Tune joystick travel and camera sensitivity in the main screen.

## Limits
- Left stick drags the on-screen movement joystick; right stick swipes the camera area; buttons hold a tap at their position. Stick mapping needs Android 14+ (the Moto is on 15).
- In-game vibration is sent by the game; this app can only test whether the controller's motor is exposed.
- Some games detect touch automation and ban for it. Use at your own risk.
- Not compiled/tested in the build environment: if Android Studio flags an error, send it over.
