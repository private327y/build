package com.varun.evofoxbridge

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.hardware.input.InputManager
import android.os.Build
import android.os.Bundle
import android.os.CombinedVibration
import android.os.VibrationEffect
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity(), InputManager.InputDeviceListener {
    private lateinit var manager: InputManager
    private lateinit var status: TextView
    private lateinit var deviceInfo: TextView
    private lateinit var eventInfo: TextView
    private lateinit var axesInfo: TextView
    private lateinit var serviceInfo: TextView
    private lateinit var enableSwitch: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        manager = getSystemService(Context.INPUT_SERVICE) as InputManager
        buildScreen()
        manager.registerInputDeviceListener(this, null)
        refreshDevices()
    }

    override fun onResume() {
        super.onResume()
        refreshService()
    }

    override fun onDestroy() {
        manager.unregisterInputDeviceListener(this)
        super.onDestroy()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(Color.rgb(14, 19, 30))
            isFocusableInTouchMode = true
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val blue = Color.rgb(125, 190, 255)

        fun text(value: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView =
            TextView(this).apply {
                text = value; textSize = size; setTextColor(color)
                if (bold) setTypeface(null, Typeface.BOLD)
                setPadding(0, 8, 0, 8)
            }

        fun button(label: String, onClick: () -> Unit): Button = Button(this).apply {
            text = label; isAllCaps = false
            setOnClickListener { onClick() }
        }

        content.addView(text("EVOFOX BRIDGE", 25f, blue, true))
        content.addView(text("Controller mapper + tester for Moto Edge 60 Fusion", 14f, Color.LTGRAY))
        status = text("Checking controller…", 20f, Color.YELLOW, true)
        content.addView(status)
        deviceInfo = text("No controller details yet", 15f)
        content.addView(deviceInfo)
        content.addView(button("Test controller vibration") { testVibration() })

        content.addView(text("MAPPING (sticks + buttons → touch)", 14f, blue, true))
        serviceInfo = text("", 14f, Color.LTGRAY)
        content.addView(serviceInfo)
        content.addView(button("1. Turn on the mapper in Accessibility settings") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        content.addView(button("2. Set up buttons and screen positions") {
            startActivity(Intent(this, CalibrateActivity::class.java))
        })
        enableSwitch = Switch(this).apply {
            text = "3. Mapping ON (start your game after this)"
            setTextColor(Color.WHITE)
            isChecked = MapConfig.enabled(this@MainActivity)
            setOnCheckedChangeListener { _, on -> MapConfig.setEnabled(this@MainActivity, on) }
        }
        content.addView(enableSwitch)

        content.addView(text("Movement joystick travel", 13f, Color.LTGRAY))
        content.addView(SeekBar(this).apply {
            max = 100
            progress = ((MapConfig.radius(this@MainActivity) - 0.06f) / 0.14f * 100).toInt().coerceIn(0, 100)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) MapConfig.setRadius(this@MainActivity, 0.06f + p / 100f * 0.14f)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        content.addView(text("Camera sensitivity", 13f, Color.LTGRAY))
        content.addView(SeekBar(this).apply {
            max = 100
            progress = ((MapConfig.lookSpeed(this@MainActivity) - 0.3f) / 1.7f * 100).toInt().coerceIn(0, 100)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) MapConfig.setLookSpeed(this@MainActivity, 0.3f + p / 100f * 1.7f)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })

        content.addView(text("LIVE BUTTON INPUT (turn mapping OFF to see mapped buttons here)", 14f, blue, true))
        eventInfo = text("Press any controller button to see it here.", 18f)
        content.addView(eventInfo)
        content.addView(text("LIVE STICK / TRIGGER AXES", 14f, blue, true))
        axesInfo = text("Move either stick or press a trigger.", 15f)
        content.addView(axesInfo)
        content.addView(text(
            "Note: games can detect touch automation and some ban for it. Use at your own risk. " +
                "In-game vibration is sent by the game itself; this app can't force it.",
            13f, Color.rgb(255, 195, 120)
        ))
        scroll.addView(content)
        root.addView(scroll)
        setContentView(root)
    }

    private fun refreshService() {
        serviceInfo.text = if (MapperService.running) "● Mapper service is ON" else "○ Mapper service is OFF — enable \"EvoFox Bridge Mapper\" in Accessibility settings"
        enableSwitch.isChecked = MapConfig.enabled(this)
    }

    private fun controllers(): List<InputDevice> =
        InputDevice.getDeviceIds().mapNotNull { InputDevice.getDevice(it) }.filter { isController(it) }

    private fun isController(device: InputDevice): Boolean {
        val sources = device.sources
        return (sources and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
            (sources and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
    }

    private fun refreshDevices() {
        val devices = controllers()
        if (devices.isEmpty()) {
            status.text = "● NO CONTROLLER DETECTED"
            status.setTextColor(Color.rgb(255, 170, 110))
            deviceInfo.text = "Connect the EvoFox Elite X2 Pro (Android mode), then press a button."
        } else {
            status.text = "● CONTROLLER DETECTED"
            status.setTextColor(Color.rgb(100, 230, 160))
            deviceInfo.text = devices.joinToString("\n\n") { d ->
                "Name: ${d.name}\nDevice ID: ${d.id}\nSources: ${sourceNames(d.sources)}\nVibration: ${if (hasMotor(d)) "motor available" else "not exposed to Android"}"
            }
        }
    }

    private fun hasMotor(d: InputDevice): Boolean =
        if (Build.VERSION.SDK_INT >= 31) d.vibratorManager.vibratorIds.isNotEmpty() else d.vibrator.hasVibrator()

    private fun testVibration() {
        val devices = controllers()
        if (devices.isEmpty()) { eventInfo.text = "No controller connected."; return }
        val sb = StringBuilder()
        for (d in devices) {
            var ok = false
            try {
                if (Build.VERSION.SDK_INT >= 31) {
                    val vm = d.vibratorManager
                    if (vm.vibratorIds.isNotEmpty()) {
                        vm.vibrate(CombinedVibration.createParallel(
                            VibrationEffect.createOneShot(600, VibrationEffect.DEFAULT_AMPLITUDE)))
                        ok = true
                    }
                } else if (d.vibrator.hasVibrator()) {
                    d.vibrator.vibrate(VibrationEffect.createOneShot(600, VibrationEffect.DEFAULT_AMPLITUDE))
                    ok = true
                }
            } catch (e: Exception) { /* fall through */ }
            sb.append("${d.name}: ").append(if (ok) "vibration sent — did it buzz?" else "no vibration motor exposed to Android").append('\n')
        }
        eventInfo.text = sb.toString().trim()
    }

    private fun sourceNames(s: Int): String {
        val names = mutableListOf<String>()
        if ((s and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD) names.add("Gamepad")
        if ((s and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK) names.add("Joystick")
        if ((s and InputDevice.SOURCE_DPAD) == InputDevice.SOURCE_DPAD) names.add("D-pad")
        return names.joinToString(", ").ifEmpty { "Other" }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (event.isGamepadButton || keyCode in KeyEvent.KEYCODE_DPAD_UP..KeyEvent.KEYCODE_DPAD_CENTER) {
            eventInfo.text = "DOWN: ${KeyEvent.keyCodeToString(keyCode)}  (code $keyCode)"
            refreshDevices()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (event.isGamepadButton || keyCode in KeyEvent.KEYCODE_DPAD_UP..KeyEvent.KEYCODE_DPAD_CENTER) {
            eventInfo.text = "UP: ${KeyEvent.keyCodeToString(keyCode)}  (code $keyCode)"
            return true
        }
        return super.onKeyUp(keyCode, event)
    }

    override fun onGenericMotionEvent(event: MotionEvent): Boolean {
        if (event.source and InputDevice.SOURCE_JOYSTICK == InputDevice.SOURCE_JOYSTICK && event.action == MotionEvent.ACTION_MOVE) {
            val names = listOf(
                MotionEvent.AXIS_X to "Left stick X", MotionEvent.AXIS_Y to "Left stick Y",
                MotionEvent.AXIS_Z to "Right stick X", MotionEvent.AXIS_RZ to "Right stick Y",
                MotionEvent.AXIS_LTRIGGER to "L2 trigger", MotionEvent.AXIS_RTRIGGER to "R2 trigger",
                MotionEvent.AXIS_HAT_X to "D-pad X", MotionEvent.AXIS_HAT_Y to "D-pad Y"
            )
            axesInfo.text = names.joinToString("\n") { (axis, label) ->
                "$label: ${"%.2f".format(event.getAxisValue(axis))}"
            }
            return true
        }
        return super.onGenericMotionEvent(event)
    }

    override fun onInputDeviceAdded(deviceId: Int) = refreshDevices()
    override fun onInputDeviceRemoved(deviceId: Int) = refreshDevices()
    override fun onInputDeviceChanged(deviceId: Int) = refreshDevices()
}
