package com.varun.evofoxbridge

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * For each action: (1) press the controller button you want to use, (2) tap where that
 * control sits on the game screen. Optionally load a screenshot of the game HUD as the
 * background so you can tap the exact spots.
 */
class CalibrateActivity : Activity() {
    private val acts = MapConfig.actions
    private var index = 0
    private var phaseKey = true
    private var armed = true
    private var shot: Bitmap? = null
    private lateinit var info: TextView
    private lateinit var board: Board

    inner class Board(c: Context) : View(c) {
        private val dot = Paint(Paint.ANTI_ALIAS_FLAG)
        private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 26f }

        override fun onDraw(canvas: Canvas) {
            shot?.let { canvas.drawBitmap(it, null, Rect(0, 0, width, height), null) }
            for ((i, a) in acts.withIndex()) {
                if (!a.hasPoint) continue
                val x = MapConfig.x(this@CalibrateActivity, a)
                val y = MapConfig.y(this@CalibrateActivity, a)
                if (x < 0f) continue
                dot.color = if (i == index) Color.YELLOW else Color.argb(200, 90, 170, 255)
                canvas.drawCircle(x * width, y * height, if (i == index) 34f else 26f, dot)
                canvas.drawText(a.id, x * width - 24f, y * height - 40f, txt)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        val root = FrameLayout(this)
        board = Board(this).apply { setBackgroundColor(Color.rgb(14, 19, 30)) }
        root.addView(board, FrameLayout.LayoutParams(-1, -1))

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.argb(190, 0, 0, 0))
            setPadding(12, 6, 12, 6)
        }
        info = TextView(this).apply { setTextColor(Color.WHITE); textSize = 13f; gravity = Gravity.CENTER }
        bar.addView(info)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label; textSize = 11f; isAllCaps = false
            setOnClickListener { onClick() }
        }.also { row.addView(it) }
        btn("Skip") { skip() }
        btn("Back") { enter(maxOf(0, index - 1)) }
        btn("Clear") { clearCurrent() }
        btn("Screenshot") { pickShot() }
        btn("Done") { finish() }
        bar.addView(row)
        root.addView(bar, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        setContentView(root)

        board.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_UP && !phaseKey && board.width > 0) {
                val a = acts[index]
                MapConfig.setPoint(this, a, e.x / board.width, e.y / board.height)
                enter(index + 1)
            }
            true
        }
        enter(0)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        }
    }

    private fun enter(i: Int) {
        if (i >= acts.size) { finish(); return }
        index = i
        val a = acts[i]
        phaseKey = a.hasKey
        refresh()
    }

    private fun skip() {
        val a = acts[index]
        if (phaseKey && a.hasPoint) { phaseKey = false; refresh() } else enter(index + 1)
    }

    private fun clearCurrent() {
        val a = acts[index]
        if (a.hasKey) MapConfig.setKey(this, a, -1)
        if (a.hasPoint) MapConfig.setPoint(this, a, -1f, -1f)
        refresh()
    }

    private fun refresh() {
        val a = acts[index]
        val k = if (a.hasKey) {
            val code = MapConfig.key(this, a)
            if (code == -1) "none" else KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_")
        } else "-"
        info.text = "${index + 1}/${acts.size}  ${a.label}   [button: $k]\n" +
            if (phaseKey) "Press the controller button for this action (or Skip)"
            else "Tap where it sits on the game screen (or Skip)"
        board.invalidate()
    }

    private fun learn(keyCode: Int) {
        val a = acts[index]
        MapConfig.setKey(this, a, keyCode)
        if (a.hasPoint) { phaseKey = false; refresh() } else enter(index + 1)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (phaseKey) {
            if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_VOLUME_UP ||
                keyCode == KeyEvent.KEYCODE_VOLUME_DOWN || keyCode == KeyEvent.KEYCODE_POWER
            ) return super.onKeyDown(keyCode, event)
            if (event.repeatCount == 0) learn(keyCode)
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    // Triggers and the D-pad often arrive as axes instead of keys.
    override fun onGenericMotionEvent(event: MotionEvent): Boolean {
        if (event.action != MotionEvent.ACTION_MOVE) return super.onGenericMotionEvent(event)
        val lt = maxOf(event.getAxisValue(MotionEvent.AXIS_LTRIGGER), event.getAxisValue(MotionEvent.AXIS_BRAKE))
        val rt = maxOf(event.getAxisValue(MotionEvent.AXIS_RTRIGGER), event.getAxisValue(MotionEvent.AXIS_GAS))
        val hx = event.getAxisValue(MotionEvent.AXIS_HAT_X)
        val hy = event.getAxisValue(MotionEvent.AXIS_HAT_Y)
        val idle = lt < 0.3f && rt < 0.3f && hx == 0f && hy == 0f
        if (idle) { armed = true; return true }
        if (!phaseKey || !armed) return true
        val code = when {
            lt > 0.8f -> KeyEvent.KEYCODE_BUTTON_L2
            rt > 0.8f -> KeyEvent.KEYCODE_BUTTON_R2
            hx < -0.5f -> KeyEvent.KEYCODE_DPAD_LEFT
            hx > 0.5f -> KeyEvent.KEYCODE_DPAD_RIGHT
            hy < -0.5f -> KeyEvent.KEYCODE_DPAD_UP
            hy > 0.5f -> KeyEvent.KEYCODE_DPAD_DOWN
            else -> return true
        }
        armed = false
        learn(code)
        return true
    }

    private fun pickShot() {
        val i = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }
        @Suppress("DEPRECATION")
        startActivityForResult(i, 7)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data ?: return
        if (requestCode != 7 || resultCode != RESULT_OK) return
        try {
            contentResolver.openInputStream(uri)?.use { s ->
                val o = BitmapFactory.Options().apply { inSampleSize = 2 }
                shot = BitmapFactory.decodeStream(s, null, o)
            }
            board.invalidate()
        } catch (e: Exception) {
            info.text = "Couldn't load that image."
        }
    }
}
