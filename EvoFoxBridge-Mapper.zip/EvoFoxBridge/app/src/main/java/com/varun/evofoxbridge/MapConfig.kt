package com.varun.evofoxbridge

import android.content.Context
import android.content.SharedPreferences
import android.view.KeyEvent

/** One thing a controller button can do: tap a spot on the screen. x/y are fractions (0..1) of the screen; -1 = not set. */
data class MapAction(
    val id: String,
    val label: String,
    val defKey: Int,
    val defX: Float,
    val defY: Float,
    val hasPoint: Boolean = true,
    val hasKey: Boolean = true
)

object MapConfig {
    val actions = listOf(
        MapAction("move", "LEFT STICK: centre of the on-screen movement joystick", -1, 0.14f, 0.68f, true, false),
        MapAction("look", "RIGHT STICK: centre of the camera/aim area", -1, 0.72f, 0.45f, true, false),
        MapAction("fire", "Fire", KeyEvent.KEYCODE_BUTTON_R2, 0.86f, 0.62f),
        MapAction("scope", "Scope / aim", KeyEvent.KEYCODE_BUTTON_L2, 0.80f, 0.42f),
        MapAction("jump", "Jump", KeyEvent.KEYCODE_BUTTON_A, 0.93f, 0.76f),
        MapAction("crouch", "Crouch", KeyEvent.KEYCODE_BUTTON_B, 0.85f, 0.86f),
        MapAction("prone", "Prone", KeyEvent.KEYCODE_BUTTON_THUMBR, 0.93f, 0.88f),
        MapAction("reload", "Reload", KeyEvent.KEYCODE_BUTTON_X, 0.70f, 0.88f),
        MapAction("interact", "Pick up / interact", KeyEvent.KEYCODE_BUTTON_Y, 0.60f, 0.62f),
        MapAction("leanl", "Lean left", KeyEvent.KEYCODE_BUTTON_L1, 0.26f, 0.20f),
        MapAction("leanr", "Lean right", KeyEvent.KEYCODE_BUTTON_R1, 0.34f, 0.20f),
        MapAction("sprint", "Sprint", KeyEvent.KEYCODE_BUTTON_THUMBL, 0.14f, 0.46f),
        MapAction("slot1", "Weapon slot 1", KeyEvent.KEYCODE_DPAD_LEFT, 0.42f, 0.93f),
        MapAction("slot2", "Weapon slot 2", KeyEvent.KEYCODE_DPAD_RIGHT, 0.50f, 0.93f),
        MapAction("map", "Map", KeyEvent.KEYCODE_DPAD_UP, 0.90f, 0.10f),
        MapAction("bag", "Backpack", KeyEvent.KEYCODE_DPAD_DOWN, 0.78f, 0.90f),
        MapAction("extra1", "Extra button 1 (e.g. M1 / back paddle)", -1, -1f, -1f),
        MapAction("extra2", "Extra button 2 (e.g. M2 / back paddle)", -1, -1f, -1f),
        MapAction("extra3", "Extra button 3 (e.g. Start)", -1, -1f, -1f),
        MapAction("extra4", "Extra button 4 (e.g. Select)", -1, -1f, -1f),
        MapAction("toggle", "Pause / resume mapping (no screen position)", KeyEvent.KEYCODE_BUTTON_MODE, -1f, -1f, false, true)
    )

    fun byId(id: String): MapAction = actions.first { it.id == id }

    private fun p(c: Context): SharedPreferences = c.getSharedPreferences("mapper", Context.MODE_PRIVATE)

    fun key(c: Context, a: MapAction): Int = p(c).getInt("key_${a.id}", a.defKey)
    fun x(c: Context, a: MapAction): Float = p(c).getFloat("x_${a.id}", a.defX)
    fun y(c: Context, a: MapAction): Float = p(c).getFloat("y_${a.id}", a.defY)

    fun setKey(c: Context, a: MapAction, keyCode: Int) {
        val e = p(c).edit()
        if (keyCode != -1) {
            // A button can only do one thing: unbind it from any other action.
            for (o in actions) if (o.id != a.id && key(c, o) == keyCode) e.putInt("key_${o.id}", -1)
        }
        e.putInt("key_${a.id}", keyCode).apply()
    }

    fun setPoint(c: Context, a: MapAction, x: Float, y: Float) {
        p(c).edit().putFloat("x_${a.id}", x).putFloat("y_${a.id}", y).apply()
    }

    fun actionForKey(c: Context, keyCode: Int): MapAction? =
        actions.firstOrNull { it.hasKey && key(c, it) == keyCode }

    fun enabled(c: Context): Boolean = p(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) = p(c).edit().putBoolean("enabled", v).apply()

    /** Movement joystick travel as a fraction of screen height. */
    fun radius(c: Context): Float = p(c).getFloat("radius", 0.12f)
    fun setRadius(c: Context, v: Float) = p(c).edit().putFloat("radius", v).apply()

    /** Camera sensitivity multiplier. */
    fun lookSpeed(c: Context): Float = p(c).getFloat("look_speed", 0.9f)
    fun setLookSpeed(c: Context, v: Float) = p(c).edit().putFloat("look_speed", v).apply()

    fun resetAll(c: Context) = p(c).edit().clear().apply()
}
