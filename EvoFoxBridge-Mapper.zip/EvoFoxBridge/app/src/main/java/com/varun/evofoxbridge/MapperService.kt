package com.varun.evofoxbridge

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Display
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.accessibility.AccessibilityEvent
import kotlin.math.abs
import kotlin.math.hypot

/**
 * Turns controller input into on-screen touches:
 *  - left stick  -> drags the on-screen movement joystick
 *  - right stick -> swipes the camera area
 *  - buttons     -> hold a tap at the position you set in the setup screen
 *
 * Android only lets one gesture run at a time, so every active touch (stick, camera, buttons)
 * is sent together in one small gesture every ~30 ms, each stroke "continuing" the last.
 */
class MapperService : AccessibilityService() {
    companion object {
        @Volatile var running = false
    }

    private class Touch {
        var stroke: GestureDescription.StrokeDescription? = null
        var x = 0f
        var y = 0f
    }

    private val handler = Handler(Looper.getMainLooper())
    private val touches = HashMap<String, Touch>()
    private val held = LinkedHashSet<String>()
    private val pendingRelease = HashSet<String>()
    private val axisState = HashMap<Int, Boolean>()
    private var busy = false

    private var lx = 0f
    private var ly = 0f
    private var rx = 0f
    private var ry = 0f
    private var lookX = 0f
    private var lookY = 0f
    private var lookActive = false

    private val tickMs = 30L

    private val loop = object : Runnable {
        override fun run() {
            try {
                tick()
            } catch (e: Exception) {
                busy = false
            }
            handler.postDelayed(this, tickMs)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        running = true
        // Android 14+: ask to observe joystick (stick) motion events.
        if (Build.VERSION.SDK_INT >= 34) {
            val info = serviceInfo
            info.motionEventSources = InputDevice.SOURCE_JOYSTICK
            serviceInfo = info
        }
        handler.post(loop)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        running = false
        handler.removeCallbacksAndMessages(null)
        return super.onUnbind(intent)
    }

    // ---------- Buttons ----------

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val d = event.device ?: return false
        if (d.sources and InputDevice.SOURCE_GAMEPAD != InputDevice.SOURCE_GAMEPAD) return false
        if (event.repeatCount > 0) {
            return MapConfig.enabled(this) && MapConfig.actionForKey(this, event.keyCode) != null
        }
        return setKeyState(event.keyCode, event.action == KeyEvent.ACTION_DOWN)
    }

    private fun setKeyState(keyCode: Int, down: Boolean): Boolean {
        val a = MapConfig.actionForKey(this, keyCode) ?: return false
        if (a.id == "toggle") {
            if (down) MapConfig.setEnabled(this, !MapConfig.enabled(this))
            return true
        }
        if (!MapConfig.enabled(this)) return false
        if (!a.hasPoint || MapConfig.x(this, a) < 0f) return false
        if (down) {
            held.add(a.id)
            pendingRelease.remove(a.id)
        } else if (a.id in held) {
            // If the tap hasn't been sent yet, keep it held until it has (so quick taps aren't lost).
            if (touches[a.id]?.stroke != null) held.remove(a.id) else pendingRelease.add(a.id)
        }
        return true
    }

    private fun axisKey(keyCode: Int, down: Boolean) {
        if ((axisState[keyCode] ?: false) != down) {
            axisState[keyCode] = down
            setKeyState(keyCode, down)
        }
    }

    // ---------- Sticks, triggers, D-pad hat (Android 14+) ----------

    override fun onMotionEvent(event: MotionEvent) {
        if (event.source and InputDevice.SOURCE_JOYSTICK != InputDevice.SOURCE_JOYSTICK) return
        if (event.action != MotionEvent.ACTION_MOVE) return

        fun dz(v: Float) = if (abs(v) < 0.15f) 0f else v
        lx = dz(event.getAxisValue(MotionEvent.AXIS_X))
        ly = dz(event.getAxisValue(MotionEvent.AXIS_Y))
        // Right stick is Z/RZ on most pads, RX/RY on some: use whichever is moving.
        val z = dz(event.getAxisValue(MotionEvent.AXIS_Z))
        val rz = dz(event.getAxisValue(MotionEvent.AXIS_RZ))
        val a = dz(event.getAxisValue(MotionEvent.AXIS_RX))
        val b = dz(event.getAxisValue(MotionEvent.AXIS_RY))
        if (abs(a) + abs(b) > abs(z) + abs(rz)) { rx = a; ry = b } else { rx = z; ry = rz }

        val lt = maxOf(event.getAxisValue(MotionEvent.AXIS_LTRIGGER), event.getAxisValue(MotionEvent.AXIS_BRAKE))
        val rt = maxOf(event.getAxisValue(MotionEvent.AXIS_RTRIGGER), event.getAxisValue(MotionEvent.AXIS_GAS))
        axisKey(KeyEvent.KEYCODE_BUTTON_L2, lt > 0.5f)
        axisKey(KeyEvent.KEYCODE_BUTTON_R2, rt > 0.5f)

        val hx = event.getAxisValue(MotionEvent.AXIS_HAT_X)
        val hy = event.getAxisValue(MotionEvent.AXIS_HAT_Y)
        axisKey(KeyEvent.KEYCODE_DPAD_LEFT, hx < -0.5f)
        axisKey(KeyEvent.KEYCODE_DPAD_RIGHT, hx > 0.5f)
        axisKey(KeyEvent.KEYCODE_DPAD_UP, hy < -0.5f)
        axisKey(KeyEvent.KEYCODE_DPAD_DOWN, hy > 0.5f)
    }

    // ---------- Gesture loop ----------

    @Suppress("DEPRECATION")
    private fun tick() {
        if (busy) return
        val enabled = MapConfig.enabled(this)
        if (!enabled) {
            held.clear()
            pendingRelease.clear()
            lookActive = false
        }

        val dm = getSystemService(DISPLAY_SERVICE) as DisplayManager
        val m = DisplayMetrics()
        dm.getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(m)
        val w = m.widthPixels
        val h = m.heightPixels

        val want = HashMap<String, FloatArray>()
        if (enabled) {
            // Left stick -> movement joystick
            if (lx != 0f || ly != 0f) {
                val mv = MapConfig.byId("move")
                val cx = MapConfig.x(this, mv) * w
                val cy = MapConfig.y(this, mv) * h
                if (touches["move"]?.stroke == null) {
                    want["move"] = floatArrayOf(cx, cy) // touch down at the centre first
                } else {
                    val r = MapConfig.radius(this) * h
                    val mag = maxOf(1f, hypot(lx, ly))
                    want["move"] = floatArrayOf(cx + lx / mag * r, cy + ly / mag * r)
                }
            }

            // Right stick -> camera swipe (re-centres when it drifts too far)
            if (rx != 0f || ry != 0f) {
                val lk = MapConfig.byId("look")
                val kx = MapConfig.x(this, lk) * w
                val ky = MapConfig.y(this, lk) * h
                if (!lookActive) {
                    lookX = kx; lookY = ky; lookActive = true
                } else {
                    val step = MapConfig.lookSpeed(this) * 0.03f * h
                    lookX += rx * step
                    lookY += ry * step
                    if (abs(lookX - kx) > 0.33f * h || abs(lookY - ky) > 0.22f * h) lookActive = false
                }
                if (lookActive) want["look"] = floatArrayOf(lookX, lookY)
            } else {
                lookActive = false
            }

            // Buttons -> held taps
            for (id in held) {
                val a = MapConfig.byId(id)
                want[id] = floatArrayOf(MapConfig.x(this, a) * w, MapConfig.y(this, a) * h)
            }
        }

        val strokes = ArrayList<GestureDescription.StrokeDescription>()
        val ids = HashSet<String>()
        ids.addAll(touches.keys)
        ids.addAll(want.keys)
        for (id in ids) {
            val t = touches.getOrPut(id) { Touch() }
            val target = want[id]
            val prev = t.stroke
            if (target != null) {
                val tx = target[0].coerceIn(1f, (w - 2).toFloat())
                val ty = target[1].coerceIn(1f, (h - 2).toFloat())
                val path = Path()
                val s: GestureDescription.StrokeDescription
                if (prev == null) {
                    path.moveTo(tx, ty)
                    s = GestureDescription.StrokeDescription(path, 0L, tickMs, true)
                } else {
                    path.moveTo(t.x, t.y)
                    if (hypot(tx - t.x, ty - t.y) >= 1f) path.lineTo(tx, ty)
                    s = prev.continueStroke(path, 0L, tickMs, true)
                }
                t.stroke = s
                t.x = tx
                t.y = ty
                strokes.add(s)
            } else if (prev != null) {
                val path = Path()
                path.moveTo(t.x, t.y)
                strokes.add(prev.continueStroke(path, 0L, 10L, false))
                t.stroke = null
            }
        }
        touches.entries.removeAll { it.value.stroke == null }

        for (id in pendingRelease.toList()) {
            if (touches[id]?.stroke != null) {
                held.remove(id)
                pendingRelease.remove(id)
            }
        }

        if (strokes.isEmpty()) return
        val builder = GestureDescription.Builder()
        for (s in strokes.take(GestureDescription.getMaxStrokeCount())) builder.addStroke(s)
        busy = true
        val ok = dispatchGesture(builder.build(), object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                busy = false
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                busy = false
                touches.clear()
                lookActive = false
            }
        }, null)
        if (!ok) busy = false
    }
}
